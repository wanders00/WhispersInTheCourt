# WhispersInTheCourt
Silly game made in Godot during a GameJam at Uni.

### Assets

[Pixel Art Top Down - Basic](https://cainos.itch.io/pixel-art-top-down-basic) - by Cainos

[Top Down Kingdom Tileset](https://swoolfeek.itch.io/king-tileset?download) - by SWoolfeek
